package exercicio2;

public abstract class FormaGeometrica {
	protected int medida1;
	protected int medida2;

	public abstract int calcularPerimetro();
	public abstract int calcularArea();
}
