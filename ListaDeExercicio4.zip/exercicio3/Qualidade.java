package exercicio3;

public enum Qualidade {
}
