package exercicio1;

public class Soma implements IOperacaoInteira{
	
	public int executar(int valora, int valorb) {
		return valora + valorb;
	}
}
