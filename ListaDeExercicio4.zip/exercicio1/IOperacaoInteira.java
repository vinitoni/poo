package exercicio1;

public interface IOperacaoInteira {
	public int executar(int valora, int valorb);
}
