package exercicio2;

public class PilhaCheiaException extends Exception{
	
	public PilhaCheiaException() {
		
	}
	
	public PilhaCheiaException(String mensagem) {
		super(mensagem);
	}
}
